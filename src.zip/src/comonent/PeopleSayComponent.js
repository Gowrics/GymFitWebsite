import React from 'react'
import SectionTitle from './SectionTitleComponent'

const PeopleSayComponent = () => {
  return (
    <div>
<section class="section textimonial position-relative bg-3">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="row justify-content-center">
					<div class="col-lg-12 text-center">
					<SectionTitle title={'What people say'}line={'___'} color='white'/>
					</div>
				</div>

				<div class="testimonial-slider">
					<div class="text-center mb-4 ">
						<i class="ti-quote-left text-lg text-color"></i>
						<h3 class="mt-4 text-white letter-spacing">A great Start to a healthy life</h3>
						<p class="my-4 text-white-50">Laboriosam molestias aperiam sit corporis sunt, hic veritatis possimus optio reprehenderit, laudantium excepturi, consequatur. Assumenda hic error veniam exercitationem</p>

						<div>
							<h4 class="mb-0 text-capitalize text-white font-weight-normal">John Donas</h4>
							<span class="text-white-50">Manager</span>
						</div>
					</div>
					<div class="text-center mb-4">
						<i class="ti-quote-left text-lg text-color"></i>
						<h3 class="mt-4 text-white letter-spacing">The workout worth attending!</h3>
						<p class="my-4 text-white-50">Laboriosam molestias aperiam sit corporis sunt, hic veritatis possimus optio reprehenderit, laudantium excepturi, consequatur. Assumenda hic error veniam exercitationem</p>
						<div>
							<h4 class="mb-0 text-capitalize text-white font-weight-normal">Donas Jack</h4>
							<span class="text-white-50">Manager</span>
						</div>
					</div>

					<div class="text-center mb-4">
						<i class="ti-quote-left text-lg text-color"></i>
						<h3 class="mt-4 text-white letter-spacing">Very Professional Club and coaches</h3>
						<p class="my-4 text-white-50">Laboriosam molestias aperiam sit corporis sunt, hic veritatis possimus optio reprehenderit, laudantium excepturi, consequatur. Assumenda hic error veniam exercitationem</p>
						<div>
							<h4 class="mb-0 text-capitalize text-white font-weight-normal" >Mikel Hussy</h4>
							<span class="text-white-50">Manager</span>
						</div>
					</div>

					<div class="text-center mb-4">
						<i class="ti-quote-left text-lg text-color"></i>
						<h3 class="mt-4 text-white letter-spacing">Shape your body and healthy!</h3>
						<p class="my-4 text-white-50">Laboriosam molestias aperiam sit corporis sunt, hic veritatis possimus optio reprehenderit, laudantium excepturi, consequatur. Assumenda hic error veniam exercitationem</p>
						<div>
							<h4 class="mb-0 text-capitalize text-white font-weight-normal">Hiker jons</h4>
							<span class="text-white-50">Manager</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
    </div>
  )
}

export default PeopleSayComponent